#!/bin/sh
mkdir docs/_build
paver sdist
