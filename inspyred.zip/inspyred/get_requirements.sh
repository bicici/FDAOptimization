#!/bin/sh
apt-get install python-pip
pip install paver
pip install sphinxcontrib-paverutils
