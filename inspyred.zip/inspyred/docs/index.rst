.. inspyred documentation index

===========================================
inspyred: Bio-inspired Algorithms in Python
===========================================

.. toctree::
   :maxdepth: 4
   
   overview
   tutorial
   examples
   recipes
   reference
   troubleshooting

=======
Indices
=======

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

