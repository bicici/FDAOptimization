from examples.standard import acs_example
from examples.standard import dea_example
from examples.standard import eda_example
from examples.standard import es_example
from examples.standard import ga_example
from examples.standard import nsga_example
from examples.standard import paes_example
from examples.standard import pso_example
from examples.standard import sa_example

__all__ = ['acs_example', 'dea_example', 'eda_example', 'es_example', 'ga_example', 
           'nsga_example', 'paes_example', 'pso_example', 'sa_example']
